# Godspeed OpenAI Plugin
This plugin connects Godspeed to OpenAI using Axios.